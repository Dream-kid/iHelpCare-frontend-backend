import { metaData } from '@utils/metaData';
import { notFound } from 'next/navigation';

export const metadata = {
  ...metaData,
  title: '404 ― iHelp',
};

export default function CatchAllPage() {
  notFound();
}
