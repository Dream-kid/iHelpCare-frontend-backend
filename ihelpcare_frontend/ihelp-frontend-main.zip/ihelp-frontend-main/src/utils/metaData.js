export const metaData = {
  title: 'iHelp',
  description:
    "Developing faith communities that are inclusive and helpful for individuals impacted by Alzheimer's.",
  authors: { name: 'Silicon Orchard Ltd.', url: 'https://www.siliconorchard.com' },
  keywords: [],
};
