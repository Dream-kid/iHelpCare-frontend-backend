import teamMember02 from '@images/team/team-member-02.png';
import teamMember03 from '@images/team/team-member-03.png';
import teamMember04 from '@images/team/team-member-04.png';

export default [
  {
    id: 1,
    name: 'Member 01',
    image: teamMember02,
  },
  {
    id: 2,
    name: 'Member 02',
    image: teamMember03,
  },
  {
    id: 3,
    name: 'Member 03',
    image: teamMember04,
  },
  {
    id: 4,
    name: 'Member 04',
    image: teamMember02,
  },
  {
    id: 5,
    name: 'Member 05',
    image: teamMember03,
  },
  {
    id: 6,
    name: 'Member 06',
    image: teamMember04,
  },
  {
    id: 7,
    name: 'Member 07',
    image: teamMember02,
  },
  {
    id: 8,
    name: 'Member 08',
    image: teamMember03,
  },
  {
    id: 9,
    name: 'Member 09',
    image: teamMember04,
  },
];
